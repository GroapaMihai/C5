package client_app.api.em;

public enum QueryType {
    SELECT, INSERT, UPDATE, DELETE;
}
